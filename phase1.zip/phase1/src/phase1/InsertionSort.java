package phase1;

public class InsertionSort {
    public static void insertionSort(int[] array) {
        int size = array.length;

        for (int i = 1; i < size; i++) {
            int key = array[i];
            int j = i - 1;

            // Move elements of the sorted subarray that are greater than the key to the right
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j--;
            }

            // Place the key in its correct position within the sorted subarray
            array[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        int[] numbers = {9, 2, 5, 1, 8, 4, 8};

        System.out.println("Before sorting:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }

        insertionSort(numbers);

        System.out.println("\nAfter sorting:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
    }
}
